function a() { alert('fhdjhgjdhfj')
    strFirstName = document.getElementById("txtIdFirstName").value;
    strLastName = document.getElementById("txtIdLastName").value;
    strDob = document.getElementById("txtIdDob").value;
    strPhoneNo = document.getElementById("txtIdPhoneNo").value;

    console.log(strFirstName)



};